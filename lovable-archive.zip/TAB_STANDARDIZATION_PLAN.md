# 🎨 TAB STANDARDIZATION PLAN

## 📊 **АНАЛИЗ ТЕКУЩИХ ВКЛАДОК:**

### **✅ ЭТАЛОН (Fresh Tokens):**
- ✅ Современный дизайн с градиентами
- ✅ Token avatar + badges
- ✅ Статистика в grid layout
- ✅ Action buttons (Watch, Pump.fun, Details)
- ✅ Hover effects
- ✅ Responsive design

### **❌ НУЖДАЮТСЯ В СТАНДАРТИЗАЦИИ:**

#### **1. Smart Money Tab** - 🔴 КРИТИЧНО
**Проблемы:**
- Старый дизайн карточек
- Нет badges для категорий
- Нет action buttons
- Нестандартная статистика

**Нужно:**
- Добавить badges (🧠 Smart, 👑 KOL, 🎯 Sniper)
- Стандартизировать статистику (ROI, Win Rate, PnL)
- Добавить action buttons (Follow, Details)
- Обновить layout

#### **2. Live Signals Tab** - 🔴 КРИТИЧНО
**Проблемы:**
- Не показывает данные (исправлено выше)
- Старый дизайн сигналов
- Нет badges для signal strength
- Нет action buttons

**Нужно:**
- Добавить signal strength badges (🔥 Hot, ⚡ Strong, 📈 Medium)
- Стандартизировать layout как Fresh Tokens
- Добавить action buttons (Watch Token, Details)

#### **3. Top Gainers Tab** - 🟡 СРЕДНИЙ ПРИОРИТЕТ
**Проблемы:**
- Простой дизайн
- Нет badges
- Ограниченная статистика

**Нужно:**
- Добавить badges (🚀 Pumping, 📈 Trending)
- Расширить статистику
- Добавить action buttons

#### **4. Coins Market Tab** - 🟡 СРЕДНИЙ ПРИОРИТЕТ
**Проблемы:**
- Базовый дизайн
- Нет badges
- Простая статистика

**Нужно:**
- Добавить badges (💰 High MC, 🔥 Hot)
- Стандартизировать layout
- Добавить action buttons

#### **5. Recent Activity Tab** - 🟡 СРЕДНИЙ ПРИОРИТЕТ
**Проблемы:**
- Простой список
- Нет badges
- Ограниченная информация

**Нужно:**
- Добавить badges (🆕 New, 🔥 Hot)
- Стандартизировать layout
- Добавить action buttons

#### **6. Portfolio Tab** - 🟡 СРЕДНИЙ ПРИОРИТЕТ
**Проблемы:**
- Базовый дизайн
- Нет badges
- Простая статистика

**Нужно:**
- Добавить badges (📊 Portfolio, 💰 Profitable)
- Стандартизировать layout
- Добавить action buttons

---

## 🎯 **СТАНДАРТНЫЙ ШАБЛОН:**

### **HTML Structure:**
```html
<div class="data-item fresh-item">
    <div class="data-header">
        <h3>
            <img src="avatar" alt="symbol" class="token-avatar">
            ${index + 1}. ${symbol} - ${name}
        </h3>
        <div class="token-badges">
            <span class="token-badge badge-new">🆕 New</span>
            <span class="token-badge badge-hot">🔥 Hot</span>
            <span class="token-badge badge-trending">📈 Trending</span>
        </div>
    </div>
    <div class="item-stats">
        <div class="stat-item">
            <div class="stat-label">Label</div>
            <div class="stat-value positive">Value</div>
        </div>
        <!-- More stats... -->
    </div>
    <div class="item-actions">
        <button class="action-button watch-btn">👁️ Watch</button>
        <a href="#" class="action-button pump-button">🔗 Link</a>
        <button class="action-button secondary">ℹ️ Details</button>
    </div>
</div>
```

### **CSS Classes:**
```css
.data-item {
    background: var(--bg-card);
    border-radius: 12px;
    padding: 20px;
    border: 1px solid var(--border-color);
    transition: all 0.3s ease;
}

.data-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 16px;
}

.token-badges {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.token-badge {
    padding: 4px 8px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
}

.item-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 12px;
    margin-bottom: 16px;
}

.item-actions {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}
```

---

## 📋 **ПЛАН РЕАЛИЗАЦИИ:**

### **Phase 1: Critical Fixes (1 час)**
1. ✅ Fix Live Signals data loading
2. 🔄 Standardize Smart Money tab
3. 🔄 Standardize Live Signals tab

### **Phase 2: Medium Priority (1 час)**
4. 🔄 Standardize Top Gainers tab
5. 🔄 Standardize Coins Market tab
6. 🔄 Standardize Recent Activity tab

### **Phase 3: Polish (30 мин)**
7. 🔄 Standardize Portfolio tab
8. 🔄 Add consistent badges across all tabs
9. 🔄 Test responsive design

---

## 🎨 **BADGE SYSTEM:**

### **Token Badges:**
- `badge-new` - 🆕 New (age < 10 min)
- `badge-hot` - 🔥 Hot (volume > 50 SOL)
- `badge-trending` - 📈 Trending (buyers > 20)
- `badge-pumping` - 🚀 Pumping (price change > 100%)

### **Trader Badges:**
- `badge-smart` - 🧠 Smart (ROI > 50%)
- `badge-whale` - 👑 Whale (volume > 100 SOL)
- `badge-sniper` - 🎯 Sniper (win rate > 80%)
- `badge-active` - ⚡ Active (trades > 50)

### **Signal Badges:**
- `badge-hot` - 🔥 Hot (strength > 8)
- `badge-strong` - ⚡ Strong (strength > 6)
- `badge-medium` - 📈 Medium (strength > 4)

---

## 🔧 **IMPLEMENTATION ORDER:**

### **1. Smart Money Tab (30 мин)**
```javascript
// Add badges based on trader metrics
let badges = '';
if (roi > 50) badges += '<span class="token-badge badge-smart">🧠 Smart</span>';
if (volume > 100) badges += '<span class="token-badge badge-whale">👑 Whale</span>';
if (winRate > 80) badges += '<span class="token-badge badge-sniper">🎯 Sniper</span>';
if (trades > 50) badges += '<span class="token-badge badge-active">⚡ Active</span>';

// Add action buttons
const actions = `
    <button class="action-button follow-btn" onclick="toggleFollowTrader('${wallet}')">
        <i class="fas fa-bell"></i> Follow
    </button>
    <button class="action-button secondary" onclick="showTraderDetails('${wallet}')">
        <i class="fas fa-chart-line"></i> Details
    </button>
`;
```

### **2. Live Signals Tab (30 мин)**
```javascript
// Add signal strength badges
let badges = '';
if (strength > 8) badges += '<span class="token-badge badge-hot">🔥 Hot</span>';
else if (strength > 6) badges += '<span class="token-badge badge-strong">⚡ Strong</span>';
else if (strength > 4) badges += '<span class="token-badge badge-medium">📈 Medium</span>';

// Add action buttons
const actions = `
    <button class="action-button watch-btn" onclick="toggleWatchToken('${mint}')">
        <i class="fas fa-eye"></i> Watch
    </button>
    <button class="action-button secondary" onclick="showTokenDetails('${mint}')">
        <i class="fas fa-info-circle"></i> Details
    </button>
`;
```

### **3. Other Tabs (1 час)**
- Apply same pattern to Top Gainers, Coins, Recent Activity, Portfolio
- Add appropriate badges for each tab type
- Standardize action buttons

---

## ✅ **SUCCESS CRITERIA:**

- [ ] All tabs use consistent HTML structure
- [ ] All tabs have appropriate badges
- [ ] All tabs have action buttons
- [ ] All tabs are responsive
- [ ] All tabs have hover effects
- [ ] All tabs follow Fresh Tokens design pattern

---

## 🚀 **READY FOR IMPLEMENTATION!**

**Priority Order:**
1. 🔴 Smart Money (Critical)
2. 🔴 Live Signals (Critical) 
3. 🟡 Top Gainers (Medium)
4. 🟡 Coins Market (Medium)
5. 🟡 Recent Activity (Medium)
6. 🟡 Portfolio (Medium)

**Total Time: 2.5 hours**

---

**Let's make all tabs look amazing! 🎨**
